<?php echo $data;?>
