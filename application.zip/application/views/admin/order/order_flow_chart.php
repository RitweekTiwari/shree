<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">
        <div class="d-md-flex">
          <div>
            <h4 class="card-title"> All ORDERS List</h4>
            <h5 class="card-subtitle">Overview of all order details information</h5>
          </div>
        </div>
        <div id="order_flow_chart" class="text-center table-responsive"></div>
      </div>
    </div>
  </div>
</div>
<?php include('_order_flow_chart.php'); ?>
