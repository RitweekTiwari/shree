<?php echo $data;?>
