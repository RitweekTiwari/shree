<?php
//Change the value of PAYTM_MERCHANT_KEY constant with details received from Paytm.
define('PAYTM_MERCHANT_KEY', '_fATwFSmd95qsU&3'); 
?>
